# Week 2 - Linear Regression using Scikit-learn
# Using sklearn to implement and evaluate linear regression

import numpy as np
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, r2_score

# Generate data
np.random.seed(42)
X = 2 * np.random.rand(100, 1)
y = 4 + 3 * X + np.random.randn(100, 1)

# Split into train and test sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
print("Training size:", len(X_train))
print("Testing size:", len(X_test))

# Train the model
model = LinearRegression()
model.fit(X_train, y_train)

print("\nIntercept:", model.intercept_[0])
print("Coefficient:", model.coef_[0][0])

# Evaluate
y_pred = model.predict(X_test)
mse = mean_squared_error(y_test, y_pred)
r2 = r2_score(y_test, y_pred)
print("\nMean Squared Error:", mse)
print("R2 Score:", r2)

# Plot
plt.scatter(X_test, y_test, label="Actual", alpha=0.7)
plt.plot(X_test, y_pred, color="red", label="Predicted")
plt.title("Linear Regression with Sklearn")
plt.xlabel("X")
plt.ylabel("y")
plt.legend()
plt.savefig("linear_regression2.png")
plt.show()
