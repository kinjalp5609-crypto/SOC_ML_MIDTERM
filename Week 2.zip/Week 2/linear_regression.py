# Week 2 - Linear Regression from Scratch
# Implementing simple linear regression using gradient descent

import numpy as np
import matplotlib.pyplot as plt

# Generate some sample data
np.random.seed(42)
X = 2 * np.random.rand(100, 1)
y = 4 + 3 * X + np.random.randn(100, 1)

# Visualize the data
plt.scatter(X, y, alpha=0.5)
plt.title("Sample Data")
plt.xlabel("X")
plt.ylabel("y")
plt.savefig("data.png")
plt.show()

# Linear Regression using Normal Equation
X_b = np.c_[np.ones((100, 1)), X]  # add bias term
theta_best = np.linalg.inv(X_b.T @ X_b) @ X_b.T @ y
print("Theta (Normal Equation):", theta_best.flatten())

# Predict
X_new = np.array([[0], [2]])
X_new_b = np.c_[np.ones((2, 1)), X_new]
y_predict = X_new_b @ theta_best

# Plot the regression line
plt.scatter(X, y, alpha=0.5, label="Data")
plt.plot(X_new, y_predict, "r-", label="Prediction")
plt.title("Linear Regression")
plt.xlabel("X")
plt.ylabel("y")
plt.legend()
plt.savefig("linear_regression.png")
plt.show()

# Linear Regression using Gradient Descent
eta = 0.1  # learning rate
n_iterations = 1000
m = 100

theta = np.random.randn(2, 1)  # random initialization

for iteration in range(n_iterations):
    gradients = 2/m * X_b.T @ (X_b @ theta - y)
    theta = theta - eta * gradients

print("Theta (Gradient Descent):", theta.flatten())
print("These values should be close to intercept=4, slope=3 which we used to generate data")
