import numpy as np

class FeedForwardNN:
    """
    A Feed-Forward Neural Network implemented from scratch using NumPy.
    """
    def __init__(self, layer_sizes, hidden_activation='relu', output_activation='sigmoid', loss_type='bce', learning_rate=0.01):
        """
        Instance Variables:
            self.layer_sizes (list of int): Stored layer dimensions.
            self.hidden_act (str):  hidden activation type. ('relu' or 'sigmoid')
            self.output_act (str):  output activation type. ('sigmoid' or 'linear')
            self.loss_type (str):  loss function type. ('mse' or 'bce')
            self.learning_rate (float):  learning rate alpha.
            self.L (int): Total number of layers (number of weight matrices).
            self.weights (list of numpy.ndarray): Weight matrices. weights[l] = W for layer l.
            self.biases (list of numpy.ndarray): Bias vectors. biases[l] = b for layer l.
            self.pre_activations (list of numpy.ndarray): Pre-activations z stored during forward pass.
            self.activations (list of numpy.ndarray): Activations a stored during forward pass.
                                                     activations[0] = X (network input).
        """
        self.layer_sizes = layer_sizes
        self.hidden_act = hidden_activation
        self.output_act = output_activation
        self.loss_type = loss_type
        self.learning_rate = learning_rate
        self.L = len(layer_sizes) - 1

        self.weights = []
        self.biases = []
        self.pre_activations = []
        self.activations = []

        self.initialize_parameters()

    def initialize_parameters(self):
        """
        TODO 1: Initialize weights and biases for each layer and append them to
        self.weights and self.biases.
        """
        np.random.seed(42)
        # Loop through each layer to create weight matrices and bias vectors
        for i in range(self.L):
            input_dim = self.layer_sizes[i]
            output_dim = self.layer_sizes[i + 1]
            
            # Simple random initialization scaled to prevent exploding gradients
            W = np.random.randn(input_dim, output_dim) * np.sqrt(2.0 / input_dim)
            b = np.zeros((1, output_dim))
            
            self.weights.append(W)
            self.biases.append(b)

    def relu(self, z):
        """
        TODO 2a: Implement the ReLU activation.
        """
        # Returns 0 if negative, else returns the value itself
        return np.maximum(0, z)

    def relu_derivative(self, z):
        """
        TODO 2b: Implement the derivative of ReLU.
        """
        # 1 if greater than 0, otherwise 0
        return (z > 0).astype(float)

    def sigmoid(self, z):
        """
        TODO 3a: Implement the Sigmoid activation.
        """
        # Cap values to keep exp from overflowing/underflowing
        clipped_z = np.clip(z, -500, 500)
        return 1.0 / (1.0 + np.exp(-clipped_z))

    def sigmoid_derivative(self, z):
        """
        TODO 3b: Implement the derivative of Sigmoid.
        """
        # Derivative formula: sigmoid(z) * (1 - sigmoid(z))
        s = self.sigmoid(z)
        return s * (1.0 - s)

    def activate(self, z, activation_type):
        """
        Routes to the correct activation function.
        """
        if activation_type == 'relu': return self.relu(z)
        elif activation_type == 'sigmoid': return self.sigmoid(z)
        elif activation_type == 'linear': return z
        else: raise ValueError("Unsupported activation")

    def forward_propagation(self, X):
        """
        TODO 4: Implement forward propagation.
        """
        self.activations = [X]
        self.pre_activations = []

        current_a = X
        for l in range(self.L):
            # z = a * W + b
            z = current_a @ self.weights[l] + self.biases[l]
            self.pre_activations.append(z)
            
            # Figure out if we need output layer activation or hidden layer activation
            if l == self.L - 1:
                act_function = self.output_act
            else:
                act_function = self.hidden_act
                
            current_a = self.activate(z, act_function)
            self.activations.append(current_a)

        return self.activations[-1]

    def compute_loss(self, output, y):
        """
        TODO 5: Compute and return the loss (MSE or BCE).
        """
        m = y.shape[0]
        
        if self.loss_type == 'mse':
            # Mean Squared Error formula
            sq_errors = (output - y) ** 2
            return np.sum(sq_errors) / (2 * m)
            
        elif self.loss_type == 'bce':
            # Binary Cross Entropy formula (with clipping to prevent log(0))
            output_safe = np.clip(output, 1e-12, 1.0 - 1e-12)
            bce_sum = y * np.log(output_safe) + (1 - y) * np.log(1 - output_safe)
            return -np.sum(bce_sum) / m
            
        else:
            raise ValueError("Unsupported loss type")

    def backward_propagation(self, y):
        """
        TODO 6: Implement backpropagation.
        """
        grad_weights = [np.zeros_like(w) for w in self.weights]
        grad_biases  = [np.zeros_like(b) for b in self.biases]

        m = y.shape[0]
        y_hat = self.activations[-1]

        # Standard delta calculation for the final output layer
        delta = y_hat - y

        # Work our way backwards through the layers
        for l in reversed(range(self.L)):
            # Calculate gradient values for weights and biases at layer l
            grad_weights[l] = (self.activations[l].T @ delta) / m
            grad_biases[l]  = np.sum(delta, axis=0, keepdims=True) / m

            # If we aren't at the first hidden layer yet, pass the delta backwards
            if l > 0:
                delta = delta @ self.weights[l].T
                
                # Multiply by derivative of the activation function used in that previous layer
                if self.hidden_act == 'relu':
                    delta = delta * self.relu_derivative(self.pre_activations[l - 1])
                elif self.hidden_act == 'sigmoid':
                    delta = delta * self.sigmoid_derivative(self.pre_activations[l - 1])

        return grad_weights, grad_biases

    def update_parameters(self, grad_weights, grad_biases):
        """
        TODO 7: Update weights and biases using gradient descent.
        """
        # Basic gradient descent parameter update rule
        for l in range(self.L):
            self.weights[l] = self.weights[l] - (self.learning_rate * grad_weights[l])
            self.biases[l] = self.biases[l] - (self.learning_rate * grad_biases[l])

    def train(self, X, y, epochs=10000, print_freq=1000):
        """
        TODO 8: Implement the training loop.
        """
        costs = []
        
        for e in range(1, epochs + 1):
            # Step 1: Forward Pass
            predictions = self.forward_propagation(X)
            
            # Step 2: Track loss
            current_loss = self.compute_loss(predictions, y)
            
            # Step 3: Backward Pass
            dW, db = self.backward_propagation(y)
            
            # Step 4: Step down the gradient
            self.update_parameters(dW, db)

            # Print updates at intervals
            if e % print_freq == 0:
                print(f"Epoch {e}/{epochs} -> Loss: {current_loss:.6f}")
                costs.append(current_loss)
                
        return costs

    def predict(self, X, threshold=0.5):
        """
        TODO 9: Implement the prediction function.
        """
        # Run forward pass to get confidence metrics
        probabilities = self.forward_propagation(X)
        
        if self.output_act == 'sigmoid':
            # Binary assignment based on threshold setting
            return (probabilities >= threshold).astype(int)
        else:
            # Continuous data output for regression setups
            return probabilities
