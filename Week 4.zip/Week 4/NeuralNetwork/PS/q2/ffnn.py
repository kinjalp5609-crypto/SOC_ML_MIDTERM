import numpy as np

class FeedForwardNN:
    """
    A Feed-Forward Neural Network implemented from scratch using NumPy.
    """
    def __init__(self, layer_sizes, hidden_activation='relu', output_activation='sigmoid', loss_type='bce', learning_rate=0.01):
        """
        Instance Variables:
            self.layer_sizes (list of int): Stored layer dimensions.
            self.hidden_act (str):  hidden activation type. ('relu' or 'sigmoid')
            self.output_act (str):  output activation type. ('sigmoid' or 'linear')
            self.loss_type (str):  loss function type. ('mse' or 'bce')
            self.learning_rate (float):  learning rate alpha.
            self.L (int): Total number of layers (number of weight matrices).
            self.weights (list of numpy.ndarray): Weight matrices. weights[l] = W for layer l.
            self.biases (list of numpy.ndarray): Bias vectors. biases[l] = b for layer l.
            self.pre_activations (list of numpy.ndarray): Pre-activations z stored during forward pass.
            self.activations (list of numpy.ndarray): Activations a stored during forward pass.
                                                     activations[0] = X (network input).
        """
        self.layer_sizes = layer_sizes
        self.hidden_act = hidden_activation
        self.output_act = output_activation
        self.loss_type = loss_type
        self.learning_rate = learning_rate
        self.L = len(layer_sizes) - 1

        self.weights = []
        self.biases = []
        self.pre_activations = []
        self.activations = []

        self.initialize_parameters()

    def initialize_parameters(self):
        """
        TODO 1: Initialize weights and biases for each layer and append them to
        self.weights and self.biases.
        """
        np.random.seed(42)
        # --- YOUR CODE HERE ---
        for l in range(self.L):
            input_neurons = self.layer_sizes[l]
            output_neurons = self.layer_sizes[l + 1]
            
            # Simple standard Gaussian weight matrix multiplied by standard scaling factor
            W = np.random.randn(input_neurons, output_neurons) * np.sqrt(2.0 / input_neurons)
            # Row bias array initializing to 0s
            b = np.zeros((1, output_neurons))
            
            self.weights.append(W)
            self.biases.append(b)
        # ----------------------

    def relu(self, z):
        """
        TODO 2a: Implement the ReLU activation.

        Args:
            z (numpy.ndarray): Pre-activation values.

        Returns:
            numpy.ndarray: Activated values.
        """
        # --- YOUR CODE HERE ---
        # Simply filters any negative values out to 0
        return np.maximum(0, z)
        # ----------------------

    def relu_derivative(self, z):
        """
        TODO 2b: Implement the derivative of ReLU.

        Args:
            z (numpy.ndarray): Pre-activation values.

        Returns:
            numpy.ndarray: Element-wise derivative values.
        """
        # --- YOUR CODE HERE ---
        # 1.0 if the input z is positive, else returns 0.0
        return (z > 0).astype(float)
        # ----------------------

    def sigmoid(self, z):
        """
        TODO 3a: Implement the Sigmoid activation.

        Args:
            z (numpy.ndarray): Pre-activation values.

        Returns:
            numpy.ndarray: Activated values.
        """
        # --- YOUR CODE HERE ---
        # Cap limits to safe zone so exponential computation doesn't explode
        z_safe = np.clip(z, -500, 500)
        return 1.0 / (1.0 + np.exp(-z_safe))
        # ----------------------

    def sigmoid_derivative(self, z):
        """
        TODO 3b: Implement the derivative of Sigmoid.

        Args:
            z (numpy.ndarray): Pre-activation values.

        Returns:
            numpy.ndarray: Element-wise derivative values.
        """
        # --- YOUR CODE HERE ---
        # Standard derivative formula: sigmoid(z) * (1 - sigmoid(z))
        s = self.sigmoid(z)
        return s * (1.0 - s)
        # ----------------------

    def activate(self, z, activation_type):
        """
        Routes to the correct activation function.

        Args:
            z (numpy.ndarray): Pre-activation values.
            activation_type (str): One of 'relu', 'sigmoid', or 'linear'.

        Returns:
            numpy.ndarray: Activated values.
        """
        if activation_type == 'relu': return self.relu(z)
        elif activation_type == 'sigmoid': return self.sigmoid(z)
        elif activation_type == 'linear': return z
        else: raise ValueError("Unsupported activation")

    def forward_propagation(self, X):
        """
        TODO 4: Implement forward propagation.

        Args:
            X (numpy.ndarray): Input data of shape (num_samples, num_features).

        Returns:
            numpy.ndarray: Final output predictions.
        """
        self.activations = [X]
        self.pre_activations = []

        # --- YOUR CODE HERE ---
        current_a = X
        for l in range(self.L):
            # Compute raw net linear output: z = a * W + b
            z = current_a @ self.weights[l] + self.biases[l]
            self.pre_activations.append(z)
            
            # Select proper activation routine based on current position
            if l == self.L - 1:
                act_type = self.output_act
            else:
                act_type = self.hidden_act
                
            current_a = self.activate(z, act_type)
            self.activations.append(current_a)

        return self.activations[-1]
        # ----------------------

    def compute_loss(self, output, y):
        """
        TODO 5: Compute and return the loss (MSE or BCE).

        Args:
            output (numpy.ndarray): Predictions from the forward pass.
            y (numpy.ndarray): True labels/targets.

        Returns:
            float: Scalar loss value.
        """
        # --- YOUR CODE HERE ---
        m = y.shape[0]
        
        if self.loss_type == 'mse':
            # Mean Squared Error calculation
            return np.sum((output - y) ** 2) / (2 * m)
            
        elif self.loss_type == 'bce':
            # Binary Cross Entropy calculation with micro-clipping protection
            output_safe = np.clip(output, 1e-12, 1.0 - 1e-12)
            total_bce = y * np.log(output_safe) + (1 - y) * np.log(1 - output_safe)
            return -np.sum(total_bce) / m
            
        else:
            raise ValueError("Unsupported loss type")
        # ----------------------

    def backward_propagation(self, y):
        """
        TODO 6: Implement backpropagation.

        Args:
            y (numpy.ndarray): True labels/targets.

        Returns:
            tuple: (grad_weights, grad_biases) where each is a list of gradients,
                   one per layer.
        """
        grad_weights = [np.zeros_like(w) for w in self.weights]
        grad_biases  = [np.zeros_like(b) for b in self.biases]

        # --- YOUR CODE HERE ---
        m = y.shape[0]
        y_hat = self.activations[-1]

        # Error gradient at the final prediction layer output (works for MSE+linear and BCE+sigmoid)
        delta = y_hat - y

        # Backtrack calculation step-by-step from output layer down to first hidden layer
        for l in reversed(range(self.L)):
            grad_weights[l] = (self.activations[l].T @ delta) / m
            grad_biases[l]  = np.sum(delta, axis=0, keepdims=True) / m

            # If there is another hidden layer behind us, propagate error delta further back
            if l > 0:
                delta = delta @ self.weights[l].T
                
                # Multiply by derivative of activation function that was used in that hidden layer
                if self.hidden_act == 'relu':
                    delta = delta * self.relu_derivative(self.pre_activations[l - 1])
                elif self.hidden_act == 'sigmoid':
                    delta = delta * self.sigmoid_derivative(self.pre_activations[l - 1])

        return grad_weights, grad_biases
        # ----------------------

    def update_parameters(self, grad_weights, grad_biases):
        """
        TODO 7: Update weights and biases using gradient descent.

        Args:
            grad_weights (list of numpy.ndarray): Weight gradients per layer.
            grad_biases  (list of numpy.ndarray): Bias gradients per layer.
        """
        # --- YOUR CODE HERE ---
        # Adjust original weights and biases by subtraction according to scale factor alpha
        for l in range(self.L):
            self.weights[l] -= self.learning_rate * grad_weights[l]
            self.biases[l]  -= self.learning_rate * grad_biases[l]
        # ----------------------

    def train(self, X, y, epochs=10000, print_freq=1000):
        """
        TODO 8: Implement the training loop.

        Args:
            X (numpy.ndarray): Input data.
            y (numpy.ndarray): True labels/targets.
            epochs (int): Number of training iterations.
            print_freq (int): Frequency of printing loss.
        """
        # --- YOUR CODE HERE ---
        history_losses = []
        
        for iteration in range(1, epochs + 1):
            # 1. Propagate data forwards
            preds = self.forward_propagation(X)
            
            # 2. Check current validation score
            loss_score = self.compute_loss(preds, y)
            
            # 3. Propagate errors backwards
            dW, db = self.backward_propagation(y)
            
            # 4. Correct tracking variables
            self.update_parameters(dW, db)

            # Print current loss metrics out every print_freq intervals
            if iteration % print_freq == 0:
                print(f"Epoch {iteration}/{epochs} — Current Loss Value: {loss_score:.6f}")
                history_losses.append(loss_score)
                
        return history_losses
        # ----------------------

    def predict(self, X, threshold=0.5):
        """
        TODO 9: Implement the prediction function.

        Args:
            X (numpy.ndarray): Input data.
            threshold (float): Threshold for binary classification.

        Returns:
            numpy.ndarray: Predicted labels or regression outputs.
        """
        # --- YOUR CODE HERE ---
        # Obtain probability estimates out of network
        network_out = self.forward_propagation(X)
        
        if self.output_act == 'sigmoid':
            # Assign binary 0 or 1 label flags checking against the classification threshold bounds
            return (network_out >= threshold).astype(int)
        else:
            # For standard linear targets, just send output predictions directly back
            return network_out
        # ----------------------
